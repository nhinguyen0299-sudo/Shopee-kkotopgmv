from flask import Flask, request, send_file, jsonify
from flask_cors import CORS
import pandas as pd
import re, io, os
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.datavalidation import DataValidation

app = Flask(__name__)
CORS(app)

KAKAO = ['kakaonline2','kakaonline3','kakaonline4','kakaonline7','kakaonline8']
DARK="1F3864"; MID="2F5496"; LIGHT="D6E4F7"; WHITE="FFFFFF"; GRAY="F2F5FA"

def clean(v):
    return re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f]', '', v) if isinstance(v, str) else v

def hdr(cell, bg=DARK, fg=WHITE, size=10):
    cell.font = Font(name='Arial', bold=True, color=fg, size=size)
    cell.fill = PatternFill('solid', start_color=bg)
    cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)

def brd(cell):
    s = Side(style='thin', color="BBBBBB")
    cell.border = Border(left=s, right=s, top=s, bottom=s)

def build_excel(df_all, months):
    agg = df_all.groupby(['Tên tài khoản KOL','Tháng','Tên Shop','ID Shop','Tên sản phẩm','Mã sản phẩm','Danh mục sản phẩm cấp 1'])['Giá trị mua hàng(₫)'].sum().reset_index()
    comm = df_all.groupby(['Tên tài khoản KOL','Tháng','Tên Shop','ID Shop','Tên sản phẩm','Mã sản phẩm','Danh mục sản phẩm cấp 1'])['Tỷ lệ hoa hồng người bán'].agg(lambda x: x.mode().iloc[0] if len(x.mode())>0 else '').reset_index()
    agg = agg.merge(comm, on=['Tên tài khoản KOL','Tháng','Tên Shop','ID Shop','Tên sản phẩm','Mã sản phẩm','Danh mục sản phẩm cấp 1'])
    agg.columns = ['Kênh','Tháng','Tên Shop','ID Shop','Tên sản phẩm','Mã sản phẩm','Ngành hàng','Tổng GMV','Tỷ lệ HH']
    agg = agg.sort_values(['Kênh','Tháng','Tổng GMV'], ascending=[True,True,False])
    agg['Rank'] = agg.groupby(['Kênh','Tháng']).cumcount() + 1
    for c in ['Tên Shop','Tên sản phẩm','Ngành hàng']: agg[c] = agg[c].apply(clean)

    wb = Workbook()

    # ── Rank_Helper ──────────────────────────────────────────────────────────
    ws_h = wb.active; ws_h.title = "Rank_Helper"
    ws_h.sheet_properties.tabColor = "95A5A6"
    ws_h.freeze_panes = 'A2'
    for c, h in enumerate(['Kênh','Tháng','Tên Shop','ID Shop','Tên sản phẩm','Mã sản phẩm','Ngành hàng','Tổng GMV (₫)','Rank','Link sản phẩm','Tỷ lệ HH người bán','Key'], 1):
        hdr(ws_h.cell(1, c, h), bg="444444")

    for ri, row in enumerate(agg.itertuples(index=False), 2):
        kenh  = str(row.Kênh)
        thang = str(row.Tháng)
        shop  = clean(str(row[2]))
        sid   = str(int(row[3])) if pd.notna(row[3]) else ''
        tensp = clean(str(row[4]))
        masp  = str(int(row[5])) if pd.notna(row[5]) else ''
        nganh = clean(str(row[6]))
        gmv   = float(row[7])
        rank  = int(row.Rank)
        hh    = str(row[8]) if pd.notna(row[8]) else ''
        link  = f'https://shopee.vn/product/{sid}/{masp}' if sid and masp else ''
        key   = f'{kenh}|{thang}|{rank}'

        ws_h.cell(ri,1,kenh); ws_h.cell(ri,2,thang); ws_h.cell(ri,3,shop)
        ws_h.cell(ri,4,sid);  ws_h.cell(ri,5,tensp); ws_h.cell(ri,6,masp)
        ws_h.cell(ri,7,nganh)
        gc = ws_h.cell(ri,8,gmv); gc.number_format='#,##0'
        ws_h.cell(ri,9,rank)
        lc = ws_h.cell(ri,10,link)
        if link:
            lc.hyperlink=link
            lc.font=Font(name='Arial',size=9,color="0563C1",underline='single')
        ws_h.cell(ri,11,hh); ws_h.cell(ri,12,key)
        if ri%2==0:
            for c in range(1,13): ws_h.cell(ri,c).fill=PatternFill('solid',start_color=GRAY)

    HL = len(agg)+1
    for col,w in zip('ABCDEFGHIJKL',[14,10,30,14,55,16,20,18,8,45,16,22]):
        ws_h.column_dimensions[col].width=w

    # ── Dashboard ────────────────────────────────────────────────────────────
    ws_d = wb.create_sheet("Dashboard", 0)
    ws_d.sheet_properties.tabColor = DARK
    ws_d.freeze_panes = 'A6'

    ws_d.row_dimensions[1].height = 40
    ws_d.merge_cells('A1:I1')
    ws_d['A1'] = "TOP 500 GMV THEO KÊNH & THÁNG — KakaOnline"
    ws_d['A1'].font = Font(name='Arial', bold=True, size=16, color=WHITE)
    ws_d['A1'].fill = PatternFill('solid', start_color=DARK)
    ws_d['A1'].alignment = Alignment(horizontal='center', vertical='center')

    ws_d.row_dimensions[2].height = 22
    ws_d.merge_cells('A2:I2')
    ws_d['A2'] = "Upload CSV lên web app → tải file Excel mới mỗi tháng"
    ws_d['A2'].font = Font(name='Arial', italic=True, size=9, color="DDDDDD")
    ws_d['A2'].fill = PatternFill('solid', start_color=DARK)
    ws_d['A2'].alignment = Alignment(horizontal='center', vertical='center')

    ws_d.row_dimensions[3].height = 32
    for lbl, col in [("Kênh:", 'A'), ("Tháng:", 'D')]:
        c = ws_d[f'{col}3']; c.value = lbl
        c.font = Font(name='Arial', bold=True, size=11)
        c.alignment = Alignment(horizontal='right', vertical='center')

    def dd(cell, val):
        cell.value = val
        cell.font = Font(name='Arial', size=11, color=MID, bold=True)
        cell.fill = PatternFill('solid', start_color=LIGHT)
        cell.alignment = Alignment(horizontal='center', vertical='center')
        s = Side(style='medium', color=MID)
        cell.border = Border(left=s,right=s,top=s,bottom=s)

    dd(ws_d['B3'], sorted(KAKAO)[0])
    dd(ws_d['E3'], months[0])

    dv_ch = DataValidation(type="list", formula1=f'"{ ",".join(sorted(KAKAO)) }"', allow_blank=False)
    dv_mo = DataValidation(type="list", formula1=f'"{ ",".join(months) }"', allow_blank=False)
    ws_d.add_data_validation(dv_ch); dv_ch.add('B3')
    ws_d.add_data_validation(dv_mo); dv_mo.add('E3')

    ws_d.row_dimensions[4].height = 8
    ws_d.row_dimensions[5].height = 32

    DASH_COLS = ['#','Tên Shop','ID Shop','Ngành hàng','Tên sản phẩm','Mã sản phẩm','Tổng GMV (₫)','Tỷ lệ HH NB','Link sản phẩm']
    for c, h in enumerate(DASH_COLS, 1):
        cell = ws_d.cell(5,c,h); hdr(cell,bg=MID); brd(cell)

    RH_MAP = [(2,'C'),(3,'D'),(4,'G'),(5,'E'),(6,'F'),(7,'H'),(8,'K'),(9,'J')]
    for i in range(1, 501):
        r = i+5
        ws_d.row_dimensions[r].height = 18
        if i==1: bg="FFD700"
        elif i==2: bg="E8E8E8"
        elif i==3: bg="CDAA7D"
        elif i%2==0: bg=LIGHT
        else: bg=WHITE

        rc = ws_d.cell(r,1,i)
        rc.font = Font(name='Arial',size=9,bold=(i<=3))
        rc.fill = PatternFill('solid',start_color=bg)
        rc.alignment = Alignment(horizontal='center',vertical='center')
        brd(rc)

        for dc, rh_cl in RH_MAP:
            f=(f'=IFERROR(INDEX(Rank_Helper!${rh_cl}$2:${rh_cl}${HL},'
               f'MATCH(Dashboard!$B$3&"|"&Dashboard!$E$3&"|"&{i},'
               f'Rank_Helper!$L$2:$L${HL},0)),"")')
            cell=ws_d.cell(r,dc,f)
            cell.font=Font(name='Arial',size=9)
            cell.fill=PatternFill('solid',start_color=bg)
            cell.alignment=Alignment(vertical='center',wrap_text=(dc==5))
            brd(cell)
            if dc==7: cell.number_format='#,##0'
            if dc==8: cell.alignment=Alignment(horizontal='center',vertical='center')
            if dc==9: cell.font=Font(name='Arial',size=9,color="0563C1",underline='single')

    for col,w in zip('ABCDEFGHI',[5,30,14,20,55,16,18,12,40]):
        ws_d.column_dimensions[col].width=w

    # Xóa sheet trống
    for name in list(wb.sheetnames):
        ws = wb[name]
        if ws.max_row<=1 and ws.max_column<=1:
            wb.remove(ws)

    output = io.BytesIO()
    wb.save(output)
    output.seek(0)
    return output

@app.route('/health', methods=['GET'])
def health():
    return jsonify({'status': 'ok'})

@app.route('/process', methods=['POST'])
def process():
    try:
        files = request.files.getlist('files')
        if not files:
            return jsonify({'error': 'Không có file nào được upload'}), 400

        dfs = []
        for f in files:
            try:
                df = pd.read_csv(f, low_memory=False, encoding='utf-8-sig')
                if df.shape[1] < 5: continue
                if 'Tên tài khoản KOL' not in df.columns: continue
                dfs.append(df)
            except Exception:
                continue

        if not dfs:
            return jsonify({'error': 'Không đọc được file CSV nào hợp lệ'}), 400

        df_all = pd.concat(dfs, ignore_index=True)
        df_all = df_all[df_all['Tên tài khoản KOL'].isin(KAKAO)].copy()

        if df_all.empty:
            return jsonify({'error': 'Không tìm thấy data của 5 kênh KakaOnline'}), 400

        df_all['Thời gian đặt hàng'] = pd.to_datetime(df_all['Thời gian đặt hàng'])
        df_all['Tháng'] = df_all['Thời gian đặt hàng'].dt.to_period('M').astype(str)

        for col in df_all.select_dtypes(include='object').columns:
            df_all[col] = df_all[col].apply(lambda x: clean(x) if isinstance(x,str) else x)

        months = sorted(df_all['Tháng'].unique().tolist())
        channels = df_all['Tên tài khoản KOL'].value_counts().to_dict()
        month = months[-1]  # latest month

        excel_file = build_excel(df_all, months)

        return send_file(
            excel_file,
            mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            as_attachment=True,
            download_name=f'Top_GMV_KakaOnline_{month}.xlsx'
        )

    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port)
